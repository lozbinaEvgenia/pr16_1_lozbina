﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr_16_consol
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputArray = Console.ReadLine().Split('/');
            int digitCount = inputArray.SelectMany(s => s).Count(char.IsDigit);
            Console.WriteLine($"Количество цифр в массиве: {digitCount}");
            foreach (var item in inputArray)
            {
                if (item == "/")
                {
                    break;
                }
                Console.WriteLine(item);
               

            }
            var elementsAfterSlash = inputArray.SkipWhile(s => s != "/").Skip(1);
            var modifiedElements = elementsAfterSlash.Select(s =>
            {
                if (s.Any(char.IsLower))
                {
                    return s.ToUpper();
                }
                else
                {
                    return s.ToLower();
                }
            });

            File.WriteAllLines("output.txt", modifiedElements) ;
        }
    }
}
